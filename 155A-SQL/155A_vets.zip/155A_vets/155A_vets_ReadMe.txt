Read the description of the vets tables in the notes for unit 02
The data values  in these inserts might not exactly match the data values shown in the notes. You can run the demos to check the current values in the tables.

Before running these scripts you need to have created the database: a_vets and have given your user permission to use that database.

It is best to run these two files are scripts from the command line; do not use copy and paste.


The order for running the scripts is
1.  run the create script - it will remove any previous copy of the tables you might have.
2.  run the inserts script - it will delete any data from the tables and then do the inserts.

If later in the semester you want to get back to the original set of data and you have not dropped any of the tables, you can just run the inserts script.



