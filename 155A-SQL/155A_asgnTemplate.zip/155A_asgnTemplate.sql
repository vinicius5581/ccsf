replace this line with a comment giving your name; I do *not* want your id, assignment number, etc.- just your name as it appears in Insight.

\W    /* enable warnings! */

use   -- put the database name into this command and REMOVE the comment. Keep the ending semicolon;

/*  TASK 00 */ 
select user(), current_date(), version(), @@sql_mode\G

/*  TASK 01 */
replace this line with your SQL for task 01

/*  TASK 02 */
replace this line with your SQL for task 02

/*  TASK 03 */


/*  TASK 04 */


/*  TASK 05 */


/*  TASK 06 */


/*  TASK 07 */


/*  TASK 08 */


/*  TASK 09 */


/*  TASK 10 */
