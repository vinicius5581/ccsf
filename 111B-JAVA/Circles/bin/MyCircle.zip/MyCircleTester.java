
public class MyCircleTester {

	public static void main(String[] args) {
		   MyCircle c1 = new MyCircle();
		   MyCircle c2 = new MyCircle();
		   MyCircle c3 = new MyCircle();
		   
		   c1.setX(2);
		   c1.setY(4);
		   c1.setRadius(4);
		   
		   c2.setX(5);
		   c2.setY(3);
		   c2.setRadius(5);
		   
		   c3.setX(10);
		   c3.setY(10);
		   c3.setRadius(3);
		   
		   
		   System.out.println("Circle 1 X: " + c1.getX());
		   System.out.println("Circle 1 Y: " + c1.getY());
		   System.out.println("Circle 1 Radius: " + c1.getRadius());
		   System.out.println("Circle 1 Area: " + c1.getArea());
		   System.out.println("");
		   System.out.println("Circle 2 X: " + c2.getX());
		   System.out.println("Circle 2 Y: " + c2.getY());
		   System.out.println("Circle 2 Radius: " + c2.getRadius());
		   System.out.println("Circle 2 Area: " + c2.getArea());
		   System.out.println("");
		   System.out.println("Circle 3 X: " + c3.getX());
		   System.out.println("Circle 3 Y: " + c3.getY());
		   System.out.println("Circle 3 Radius: " + c3.getRadius());
		   System.out.println("Circle 3 Area: " + c3.getArea());
		   System.out.println("");
		   System.out.println("Circle 1 overlap Circle 2: " + c1.doesOverlap(c2));
		   System.out.println("Circle 1 overlap Circle 3: " + c1.doesOverlap(c3));
		   System.out.println("Circle 2 overlap Circle 3: " + c2.doesOverlap(c3));	   
	}

}
