As usual, copy LAB06 into your own PYLABS directory.

$ cp -r ~uwostner/wostnotes/LAB06 ~/PYLABS/

Then, for instructions, due date, etc, you have two ways:

    $ cd ~/PYLABS/LAB06

    $ pydoc3 cardslab

or on the web

    http://hills.ccsf.edu/~uwostner/cs131a/cardslab.html


Good luck everybody!

Ulf


PS. There will be a BONUS lab later that uses the cardslab. It will be about either blackjack ("31") or about poker.


