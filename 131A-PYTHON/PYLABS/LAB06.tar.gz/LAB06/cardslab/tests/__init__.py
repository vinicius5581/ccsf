"""Copyright (c) 2015 Ulf Wostner <wostner@cyberprof.com> All rights reserved. Do not post, share or distribute in any form.

"""
